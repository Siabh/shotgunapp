package com.emac.gipsi.shotgun.services;

import java.util.List;

import com.emac.gipsi.shotgun.model.Residence;

public interface IResidenceService {
	public List<Residence> getResidences();
}
