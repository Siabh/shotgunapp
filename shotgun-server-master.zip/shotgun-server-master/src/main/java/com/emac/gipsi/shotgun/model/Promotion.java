package com.emac.gipsi.shotgun.model;

public enum Promotion {
	M1, M2, L3, L1, L2
}
