package com.emac.gipsi.shotgun.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.emac.gipsi.shotgun.model.PartieCommune;

public interface PartieCommuneRepository extends JpaRepository<PartieCommune, Integer> {

}
