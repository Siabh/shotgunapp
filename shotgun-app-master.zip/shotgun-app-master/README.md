# Shotgun App

# Lancement
Pour le lancer, il faut d'abord installer Angular via `npm install @angular/cli -g`.
Puis, tous les packages via `npm install` en étant dans le dossier du projet.

Une fois que tout est installé, l'appli peut être lancée en faisant `ng serve`. Le résultat est visible à l'adresse `http://localhost:4200`. 
